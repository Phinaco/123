import { FormLogin } from "../../ui"
// import { Logo } from '../../../public/logo_bsale.svg'
// import { FormLogin } from '../ui'
export const Login = () => {
    return (
        <>
            {/* <FormLogin /> */}
            {/* <img src={Logo}></img> */}
            <FormLogin />
            
        </>
    )
}