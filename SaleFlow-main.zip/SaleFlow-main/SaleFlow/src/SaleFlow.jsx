import { AppRouter } from "./router/AppRouter"

export const SaleFlow = () => {
    return (
        <>
            <AppRouter />
        </>
    )
}