import { Navbar } from "../../ui"


export const CashRegister = () => {

    return (
        <>
            <h1>CashRegister</h1>
        </>
    )
}